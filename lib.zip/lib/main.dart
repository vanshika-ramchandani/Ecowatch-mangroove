import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'l10n/app_localizations.dart'; // Import the manual localization
import 'screens/dashboard_screen.dart'; // Add this import
import 'screens/citizen_auth_screen.dart'; // Add this import
import 'screens/citizen_dashboard.dart'; // Add this import

void main() {
  runApp(const EcoWatchApp());
}

class EcoWatchApp extends StatelessWidget {
  const EcoWatchApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Eco Watch',
      theme: ThemeData(
        primarySwatch: Colors.green,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      // home: const DashboardScreen(), // Remove this line
      initialRoute: '/', // Add this instead
      routes: {
        '/': (context) => const DashboardScreen(),
        '/citizen-auth': (context) => const CitizenAuthScreen(),
        '/citizen-dashboard': (context) => const CitizenDashboard(),
      },
      localizationsDelegates: const [
        AppLocalizations.delegate, // Your manual delegate
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      supportedLocales: const [
        Locale('en', 'US'), // English
        Locale('hi', 'IN'), // Hindi
        Locale('es', 'ES'), // Spanish
        Locale('fr', 'FR'), // French
      ],
    );
  }
}